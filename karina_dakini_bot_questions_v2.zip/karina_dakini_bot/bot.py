import asyncio
import logging
import os
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
)
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "").strip()
LECTURE_PAYMENT_URL = os.getenv("LECTURE_PAYMENT_URL", "").strip()
PDF_PATH = Path(os.getenv("PDF_PATH", "minciu_architektura.pdf"))

if not BOT_TOKEN:
    raise RuntimeError("Nerastas BOT_TOKEN. Įrašyk jį į .env failą.")

logging.basicConfig(level=logging.INFO)
dp = Dispatcher(storage=MemoryStorage())


class QuestionFlow(StatesGroup):
    anonymity = State()
    question = State()


def main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💬 Užduoti klausimą Karina", callback_data="ask_question")],
        [InlineKeyboardButton(text="🌿 Gauti nemokamą gidą", callback_data="get_guide")],
        [InlineKeyboardButton(text="📖 Lapkričio 1 d. paketas – 19,99 €", callback_data="lecture")],
    ])


WELCOME_TEXT = (
    "Sveiki atvykę į „Karina Dakini“ erdvę 🌿\n\n"
    "Iki spalio 20 d. kviečiu užduoti klausimus apie mąstymo modelius, vidinius įsitikinimus, "
    "pasikartojančias mintis ir savęs pažinimą. Jūsų klausimai padės man geriau parengti turinį.\n\n"
    "Lapkričio 1 d. pristatysiu „Minčių architektūros“ PDF gidą ir įrašytą paskaitą "
    "už simbolinę 19,99 € kainą.\n\n"
    "Tai edukacinis projektas – be stebuklų pažadų, su žiniomis, praktiniais pavyzdžiais "
    "ir savirefleksija.\n\n"
    "Pasirink, nuo ko norėtum pradėti:"
)


@dp.message(CommandStart())
async def start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(WELCOME_TEXT, reply_markup=main_keyboard())


@dp.message(Command("help"))
async def help_command(message: Message) -> None:
    await message.answer("Naudok /start, kad pamatytum meniu.", reply_markup=main_keyboard())


@dp.message(Command("myid"))
async def my_id(message: Message) -> None:
    await message.answer(
        f"Tavo Telegram ID: {message.from_user.id}\n"
        "Šį skaičių įrašyk į .env eilutę ADMIN_CHAT_ID=..."
    )


@dp.callback_query(F.data == "ask_question")
async def ask_question(callback: CallbackQuery, state: FSMContext) -> None:
    await callback.answer()
    await state.set_state(QuestionFlow.anonymity)
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🕊️ Siųsti anonimiškai", callback_data="anon_yes")],
        [InlineKeyboardButton(text="👤 Gali matyti mano vardą", callback_data="anon_no")],
        [InlineKeyboardButton(text="⬅️ Atšaukti", callback_data="cancel_question")],
    ])
    await callback.message.answer(
        "Kviečiu parašyti klausimą apie mintis, įsitikinimus ar savęs pažinimą.\n\n"
        "Pasirink, ar nori, kad klausimas man būtų perduotas anonimiškai. "
        "Anonimiškumas reiškia, kad boto perduodamoje žinutėje nenurodysiu tavo vardo ar Telegram profilio.",
        reply_markup=keyboard,
    )


@dp.callback_query(F.data.in_({"anon_yes", "anon_no"}), QuestionFlow.anonymity)
async def choose_anonymity(callback: CallbackQuery, state: FSMContext) -> None:
    await callback.answer()
    anonymous = callback.data == "anon_yes"
    await state.update_data(anonymous=anonymous)
    await state.set_state(QuestionFlow.question)
    await callback.message.answer(
        "Parašyk savo klausimą viena žinute. Prašau nesiųsti slaptažodžių, asmens kodų ar kitos jautrios informacijos.\n\n"
        "Jei persigalvojai, parašyk /cancel."
    )


@dp.message(QuestionFlow.question, Command("cancel"))
async def cancel_question(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Klausimo siuntimas atšauktas.", reply_markup=main_keyboard())


@dp.message(QuestionFlow.question, F.text)
async def receive_question(message: Message, state: FSMContext, bot: Bot) -> None:
    data = await state.get_data()
    anonymous = bool(data.get("anonymous", True))
    user = message.from_user
    question_text = message.text.strip()

    if len(question_text) < 3:
        await message.answer("Parašyk šiek tiek ilgesnį klausimą arba /cancel, jei nori atšaukti.")
        return

    if not ADMIN_CHAT_ID:
        await message.answer(
            "Ačiū, tavo klausimas paruoštas, tačiau boto administratorius dar nesukonfigūravo klausimų gavimo. "
            "Pabandyk vėliau."
        )
        logging.warning("Gautas klausimas, bet ADMIN_CHAT_ID nenustatytas.")
        await state.clear()
        return

    if anonymous:
        admin_text = (
            "🌿 NAUJAS ANONIMINIS KLAUSIMAS\n\n"
            f"{question_text}\n\n"
            "Atsakant viešai, neskelbk informacijos, pagal kurią būtų galima atpažinti žmogų."
        )
    else:
        display_name = user.full_name if user else "Telegram naudotojas"
        username = f" (@{user.username})" if user and user.username else ""
        admin_text = (
            "🌿 NAUJAS KLAUSIMAS\n\n"
            f"Siuntėjas: {display_name}{username}\n"
            f"Telegram ID: {user.id if user else 'nežinomas'}\n\n"
            f"{question_text}"
        )

    try:
        await bot.send_message(chat_id=int(ADMIN_CHAT_ID), text=admin_text)
    except Exception:
        logging.exception("Nepavyko perduoti klausimo administratoriui.")
        await message.answer(
            "Ačiū už klausimą. Šiuo metu nepavyko jo perduoti, todėl pabandyk dar kartą vėliau."
        )
        await state.clear()
        return

    await message.answer(
        "Ačiū, gavau tavo klausimą 🌿\n\n"
        "Jis padės man geriau suprasti, kokios temos jums svarbios ruošiant „Minčių architektūrą“.\n"
        "Tai nėra individuali psichologinė konsultacija; atsakymus į dažniausiai pasikartojančius klausimus "
        "galėsiu aptarti edukaciniame turinyje.",
        reply_markup=main_keyboard(),
    )
    await state.clear()


@dp.message(QuestionFlow.question)
async def non_text_question(message: Message) -> None:
    await message.answer("Prašau klausimą parašyti tekstu. Jei nori atšaukti, parašyk /cancel.")


@dp.callback_query(F.data == "cancel_question")
async def cancel_question_button(callback: CallbackQuery, state: FSMContext) -> None:
    await callback.answer()
    await state.clear()
    await callback.message.answer("Gerai, klausimo nesiųsime.", reply_markup=main_keyboard())


@dp.callback_query(F.data == "get_guide")
async def send_guide(callback: CallbackQuery) -> None:
    await callback.answer()
    if not PDF_PATH.is_file():
        await callback.message.answer(
            "PDF gidas dar ruošiamas. Kai jis bus parengtas, įdėsiu jį į boto aplanką.\n\n"
            "Iki spalio 20 d. gali užduoti man klausimą, o lapkričio 1 d. planuoju pristatyti "
            "gidą ir paskaitos įrašą.",
            reply_markup=main_keyboard(),
        )
        return

    await callback.message.answer_document(
        document=FSInputFile(PDF_PATH),
        caption=(
            "🌿 Tavo gidas „Minčių architektūra“.\n\n"
            "Tai edukacinė medžiaga savirefleksijai, ne individuali psichologinė ar medicininė pagalba."
        ),
    )


@dp.callback_query(F.data == "lecture")
async def lecture_info(callback: CallbackQuery) -> None:
    await callback.answer()
    text = (
        "🌿 MINČIŲ ARCHITEKTŪRA\n"
        "NLP, vidiniai įsitikinimai ir sąmoningo pokyčio praktika\n\n"
        "Lapkričio 1 d. planuoju pristatyti PDF gidą ir įrašytą edukacinę paskaitą.\n\n"
        "Paketą sudarys:\n"
        "• PDF gidas savarankiškam skaitymui;\n"
        "• paskaitos įrašas, kurį galėsi žiūrėti tau patogiu metu;\n"
        "• praktiniai savirefleksijos klausimai.\n\n"
        "Kaina: 19,99 €.\n"
        "Paskaita yra edukacinio pobūdžio ir nežada gydymo ar garantuoto rezultato."
    )
    if LECTURE_PAYMENT_URL:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="💳 Įsigyti paketą – 19,99 €", url=LECTURE_PAYMENT_URL)],
            [InlineKeyboardButton(text="⬅️ Grįžti į meniu", callback_data="menu")],
        ])
        await callback.message.answer(text, reply_markup=keyboard)
    else:
        await callback.message.answer(
            text + "\n\nMokėjimo nuoroda bus pridėta, kai ją paruoši.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="⬅️ Grįžti į meniu", callback_data="menu")]
            ]),
        )


@dp.callback_query(F.data == "menu")
async def back_to_menu(callback: CallbackQuery) -> None:
    await callback.answer()
    await callback.message.answer(WELCOME_TEXT, reply_markup=main_keyboard())


async def main() -> None:
    async with Bot(token=BOT_TOKEN) as bot:
        me = await bot.get_me()
        logging.info("Botas paleistas: @%s", me.username)
        await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
