KARINA DAKINI – TELEGRAM BOTAS (VERSIJA 2)

Ką daro ši versija:
- /start parodo pasveikinimą ir meniu.
- „Užduoti klausimą Karina“ leidžia pasirinkti anoniminį arba su vardu klausimą.
- Klausimas persiunčiamas administratoriui, kai sukonfigūruotas ADMIN_CHAT_ID.
- /myid parodo tavo Telegram ID.
- PDF mygtukas išsiunčia minciu_architektura.pdf, kai failas bus įdėtas į aplanką.
- Paskaitos paketo kaina pakeista į 19,99 €, numatyta data – lapkričio 1 d.

ĮDIEGIMAS
1. Įsidiek Python 3.11 arba naujesnę versiją: https://www.python.org/downloads/
2. Išskleisk ZIP failą.
3. Aplanke nukopijuok .env.example į .env.
4. Į .env įrašyk BOT_TOKEN iš @BotFather.
5. Terminale, šiame aplanke, paleisk:

Windows:
  py -m venv .venv
  .venv\Scripts\activate
  pip install -r requirements.txt
  python bot.py

Mac:
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  python bot.py

ADMIN ID NUSTATYMAS
1. Pirmą kartą paleisk botą ir atsidaryk savo botą Telegram.
2. Paspausk Start ir išsiųsk /myid.
3. Nukopijuok parodytą skaičių į .env eilutę ADMIN_CHAT_ID=...
4. Sustabdyk ir vėl paleisk botą.

PDF
Įdėk paruoštą failą minciu_architektura.pdf į tą patį aplanką kaip bot.py.

SVARBU
- Anoniminis režimas reiškia, kad botui perduodamoje žinutėje nebus nurodytas siuntėjo vardas ar ID.
  Telegram pats vis tiek apdoroja naudotojo paskyrą, o botą valdantis asmuo gali matyti gautą turinį.
  Paprašyk žmonių nerašyti jautrių asmens duomenų.
- Mokėjimai šiame etape nėra automatiškai patvirtinami.
- Botas veikia tik tada, kai bot.py procesas veikia. Veikimui 24/7 vėliau reikės serverio.
- Nekelk .env failo ar tokeno į viešą saugyklą.
